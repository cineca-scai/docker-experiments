#RISE

**Reveal.js - Jupyter/IPython Slideshow Extension**, also known as *live_reveal*

